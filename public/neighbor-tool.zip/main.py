# Python 3.9 호환: dict | None 등 신형 타입표기를 지연 평가(문자열)로 처리
#   (Mac 기본 내장 python3 이 3.9 인 경우 'unsupported operand |' 오류 방지)
from __future__ import annotations

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import threading
import queue
import time
import random
import json
import os
import hashlib
import datetime
import platform
import tempfile

# Windows: 콘솔 창으로 실행되더라도 즉시 숨긴다 (뒤에 검은 창 방지)
#   - bat → pythonw 로 실행하면 콘솔이 없어 아무 동작 안 함
#   - .py 를 직접 더블클릭해 python.exe 로 떠도 검은 창을 숨김
if platform.system() == "Windows":
    try:
        import ctypes
        _con = ctypes.windll.kernel32.GetConsoleWindow()
        if _con:
            ctypes.windll.user32.ShowWindow(_con, 0)  # 0 = SW_HIDE
    except Exception:
        pass

BASE_DIR    = os.path.dirname(os.path.abspath(__file__))
CONFIG_FILE = os.path.join(BASE_DIR, "설정.json")
KEYS_FILE   = os.path.join(BASE_DIR, "api_keys.json")
APP_TITLE   = "Nbolg 서로이웃 자동화 v1.0"

try:
    from selenium import webdriver
    from selenium.webdriver.common.by import By
    from selenium.webdriver.chrome.service import Service
    from selenium.webdriver.support.ui import WebDriverWait, Select
    from selenium.webdriver.support import expected_conditions as EC
    from webdriver_manager.chrome import ChromeDriverManager
    from urllib.parse import quote
    SELENIUM_OK = True
except ImportError as _e:
    SELENIUM_OK = False
    IMPORT_ERROR = str(_e)


class AuthDialog(tk.Toplevel):
    def __init__(self, parent: tk.Tk):
        super().__init__(parent)
        self.title("API 키 인증")
        self.resizable(False, False)
        self.attributes("-topmost", True)
        self.grab_set()
        self.result: str | None = None
        self._build()
        self._center()
        self._force_front()
        self.wait_window()

    def _force_front(self):
        """다른 창에 가려지지 않도록 다이얼로그를 강제로 최상단에 올린다."""
        self.deiconify()
        self.attributes("-topmost", True)
        self.lift()
        self.focus_force()
        self.entry.focus_set()
        # 일부 환경에서 다른 창 뒤로 밀리는 것을 막기 위해 잠시 후 한 번 더 끌어올림
        self.after(200, self._reassert_front)

    def _reassert_front(self):
        try:
            self.lift()
            self.attributes("-topmost", True)
            self.focus_force()
        except Exception:
            pass

    def _center(self):
        """다이얼로그를 화면 중앙에 배치한다."""
        self.update_idletasks()
        w = self.winfo_reqwidth()
        h = self.winfo_reqheight()
        x = (self.winfo_screenwidth() - w) // 2
        y = (self.winfo_screenheight() - h) // 3
        self.geometry(f"+{x}+{y}")

    def _build(self):
        tk.Label(self, text="Nbolg 서로이웃 자동화",
                 font=("", 11, "bold"), pady=10).pack()
        tk.Label(self, text="발급받은 API 키를 입력하세요.",
                 fg="#555").pack(padx=24)
        self.entry = tk.Entry(self, show="*", width=34,
                              font=("Consolas", 11), relief="solid")
        self.entry.pack(padx=24, pady=(8, 4))
        self.entry.focus_set()

        self.show_var = tk.BooleanVar(value=False)
        tk.Checkbutton(self, text="키 표시", variable=self.show_var,
                       command=self._toggle_show).pack(anchor="e", padx=26)

        bf = tk.Frame(self)
        bf.pack(pady=12)
        tk.Button(bf, text="  확인  ", command=self._ok,
                  bg="#4CAF50", fg="white", relief="flat", pady=5).pack(side="left", padx=6)
        tk.Button(bf, text="  취소  ", command=self.destroy,
                  relief="flat", pady=5).pack(side="left", padx=6)

        self.bind("<Return>", lambda _: self._ok())
        self.bind("<Escape>", lambda _: self.destroy())

    def _toggle_show(self):
        self.entry.config(show="" if self.show_var.get() else "*")

    def _ok(self):
        self.result = self.entry.get().strip()
        self.destroy()


class NaverAutoApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title(APP_TITLE)
        self.root.resizable(False, False)

        # 인증 전에는 빈 메인 창을 숨겨 둔다 (인증 다이얼로그만 보이도록)
        self.root.withdraw()

        if not self._check_api_key():
            root.after(100, root.destroy)
            return

        # 인증 성공 → 메인 창 표시
        self.root.deiconify()

        self.running = False
        self.log_queue: queue.Queue[str] = queue.Queue()

        self.var_keyword        = tk.StringVar(value="")
        self.var_scroll_count   = tk.IntVar(value=10)
        self.var_buddy_interval = tk.IntVar(value=10)

        self._load_config_vars()
        self._build_ui()
        self._load_config_texts()
        self._poll_log()

        if not SELENIUM_OK:
            self.log(f"[경고] 패키지 오류: {IMPORT_ERROR}")
            self.log("CMD: pip install selenium webdriver-manager")

    # ── API 키 인증 ───────────────────────────────────────────────

    def _check_api_key(self) -> bool:
        if not os.path.exists(KEYS_FILE):
            messagebox.showerror(
                "인증 오류",
                "API 키 파일(api_keys.json)이 없습니다.\n관리자에게 문의하세요.")
            return False

        try:
            with open(KEYS_FILE, encoding="utf-8") as f:
                keys = json.load(f).get("keys", [])
        except Exception:
            messagebox.showerror("인증 오류", "키 파일을 읽을 수 없습니다.")
            return False

        if not keys:
            messagebox.showerror("인증 오류", "등록된 키가 없습니다.\n관리자에게 문의하세요.")
            return False

        dlg = AuthDialog(self.root)
        key = dlg.result
        if not key:
            return False

        key_hash = hashlib.sha256(key.strip().encode("utf-8")).hexdigest()
        for k in keys:
            if k.get("key_hash") != key_hash:
                continue
            if not k.get("active", True):
                messagebox.showerror("인증 실패", "비활성화된 키입니다.\n관리자에게 문의하세요.")
                return False
            expires_at = k.get("expires_at")
            if expires_at:
                try:
                    if datetime.date.fromisoformat(expires_at) < datetime.date.today():
                        messagebox.showerror(
                            "키 만료",
                            f"키가 만료되었습니다. (만료일: {expires_at})\n관리자에게 재발급을 요청하세요.")
                        return False
                except ValueError:
                    pass
            return True

        messagebox.showerror("인증 실패", "유효하지 않은 키입니다.\n관리자에게 문의하세요.")
        return False

    # ── UI ───────────────────────────────────────────────────────

    def _build_ui(self):
        nb = ttk.Notebook(self.root)
        nb.pack(fill="both", expand=True, padx=6, pady=(6, 0))
        tab1 = tk.Frame(nb, bg="#f0f0f0")
        nb.add(tab1, text="프로그램 기본 설정")
        self._build_tab1(tab1)
        self._build_bottom(self.root)

    def _build_tab1(self, parent: tk.Frame):
        canvas = tk.Canvas(parent, bg="#f0f0f0", width=460, height=360, highlightthickness=0)
        sb = ttk.Scrollbar(parent, orient="vertical", command=canvas.yview)
        inner = tk.Frame(canvas, bg="#f0f0f0")
        inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=inner, anchor="nw")
        canvas.configure(yscrollcommand=sb.set)
        canvas.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        canvas.bind_all("<MouseWheel>",
                        lambda e: canvas.yview_scroll(-1 * (e.delta // 120), "units"))

        f = inner
        pad = {"padx": 10, "pady": 3}

        def sep(row):
            ttk.Separator(f, orient="horizontal").grid(
                row=row, column=0, columnspan=3, sticky="ew", padx=8, pady=4)

        def lbl(text, row, bold=False):
            tk.Label(f, text=text, font=("", 9, "bold" if bold else ""),
                     bg="#f0f0f0").grid(row=row, column=0, columnspan=3, sticky="w", **pad)

        def spin(var, row, text, suffix="", from_=1, to=120, note=""):
            tk.Label(f, text=text, bg="#f0f0f0").grid(row=row, column=0, sticky="w", **pad)
            tk.Spinbox(f, from_=from_, to=to, width=5,
                       textvariable=var).grid(row=row, column=1, sticky="w", pady=3)
            note_lbl = tk.Label(f, text=f"{suffix}  {note}", bg="#f0f0f0")
            note_lbl.grid(row=row, column=2, sticky="w")
            return note_lbl

        def textarea(attr, row, h=4):
            t = tk.Text(f, height=h, width=48, wrap="word", relief="solid", bd=1)
            t.grid(row=row, column=0, columnspan=3, padx=10, pady=2)
            setattr(self, attr, t)

        # ── 로그인 안내 ────────────────────────────────
        lbl("▸ 사용 순서", 0, bold=True)
        notice = tk.Label(
            f,
            text="① 'Chrome 시작' 버튼 클릭 → 열린 Chrome에서 네이버 로그인\n"
                 "② 로그인 완료 후 '서로이웃 시작' 클릭\n"
                 "   (로그인은 처음 한 번만 — 이후 쿠키 자동 유지)",
            bg="#FFF9C4", fg="#555", justify="left",
            relief="flat", padx=8, pady=6
        )
        notice.grid(row=1, column=0, columnspan=3, sticky="ew", padx=10, pady=4)
        sep(2)

        # ── 블로그 수집 ────────────────────────────────
        lbl("▸ 블로그 수집 설정", 3, bold=True)
        tk.Label(f, text="1. 검색 키워드", bg="#f0f0f0").grid(
            row=4, column=0, sticky="w", **pad)
        tk.Entry(f, textvariable=self.var_keyword, width=18).grid(
            row=4, column=1, sticky="w", pady=3)
        tk.Label(f, text="키워드로 검색해 최신순으로 가져옵니다",
                 fg="#888", bg="#f0f0f0", font=("", 8)).grid(
            row=4, column=2, sticky="w")
        self.lbl_scroll_note = spin(self.var_scroll_count, 5, "2. 스크롤 횟수", "회",
                                    from_=1, to=50)
        self._update_scroll_note()
        self.var_scroll_count.trace_add("write", lambda *_: self._update_scroll_note())
        sep(6)

        # ── 서로이웃 설정 ──────────────────────────────
        lbl("▸ 서로이웃 설정", 7, bold=True)
        spin(self.var_buddy_interval, 8, "3. 신청 간격", "초",
             from_=5, to=120, note="(랜덤 ±3초 자동 적용)")
        lbl("4. 서로이웃 신청 메시지 (400자 이내)", 9)
        textarea("txt_buddy_msg", 10, h=5)
        sep(11)

        tk.Button(f, text="  설정 저장  ", command=self._save_config,
                  bg="#607D8B", fg="white", relief="flat", padx=8).grid(
            row=12, column=2, sticky="e", padx=10, pady=6)

    def _update_scroll_note(self):
        """스크롤 횟수에 따라 예상 서로이웃 신청 인원을 실시간 표시."""
        try:
            n = self.var_scroll_count.get()
        except Exception:
            return  # 입력칸이 비었거나 숫자가 아닐 때
        self.lbl_scroll_note.config(
            text=f"회   (약 {n * 20}~{n * 30}명 서로이웃 신청 예정)")

    def _build_bottom(self, parent):
        bf = tk.Frame(parent, bg="#e8e8e8", pady=5)
        bf.pack(fill="x", padx=6)

        def btn(text, color, cmd, w=14):
            return tk.Button(bf, text=text, bg=color, fg="white",
                             width=w, relief="flat", pady=4, command=cmd)

        self.btn_chrome = btn("① Chrome 시작",   "#FF9800", self._launch_chrome, 13)
        self.btn_buddy  = btn("② 서로이웃 시작", "#4CAF50", self._start_buddy, 13)
        self.btn_stop   = btn("■ 중지",           "#f44336", self._stop_all, 8)
        self.btn_chrome.pack(side="left", padx=4)
        self.btn_buddy.pack(side="left", padx=4)
        self.btn_stop.pack(side="left", padx=4)
        self.btn_stop.configure(state="disabled")

        lf = tk.LabelFrame(parent, text=" 실행 로그 ", bg="#f9f9f9")
        lf.pack(fill="both", expand=True, padx=6, pady=(4, 6))
        self.log_text = scrolledtext.ScrolledText(
            lf, height=9, state="disabled", wrap="word",
            font=("Consolas", 8), bg="#1e1e1e", fg="#d4d4d4"
        )
        self.log_text.pack(fill="both", expand=True, padx=3, pady=3)

    # ── 설정 저장/로드 ────────────────────────────────────────────

    def _get_config(self) -> dict:
        return {
            "keyword":        self.var_keyword.get(),
            "scroll_count":   self.var_scroll_count.get(),
            "buddy_interval": self.var_buddy_interval.get(),
            "buddy_msg":      self.txt_buddy_msg.get("1.0", "end-1c"),
        }

    def _save_config(self):
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(self._get_config(), f, ensure_ascii=False, indent=2)
        messagebox.showinfo("저장 완료", "설정이 저장되었습니다.")

    def _load_config_vars(self):
        if not os.path.exists(CONFIG_FILE):
            return
        try:
            with open(CONFIG_FILE, encoding="utf-8") as f:
                cfg = json.load(f)
            self.var_keyword.set(cfg.get("keyword", ""))
            self.var_scroll_count.set(cfg.get("scroll_count", 10))
            self.var_buddy_interval.set(cfg.get("buddy_interval", 10))
        except Exception:
            pass

    def _load_config_texts(self):
        if not os.path.exists(CONFIG_FILE):
            return
        try:
            with open(CONFIG_FILE, encoding="utf-8") as f:
                cfg = json.load(f)
            if cfg.get("buddy_msg"):
                self.txt_buddy_msg.delete("1.0", "end")
                self.txt_buddy_msg.insert("1.0", cfg["buddy_msg"])
        except Exception:
            pass

    # ── 버튼 / 로그 ───────────────────────────────────────────────

    def _set_buttons(self, running: bool):
        s = "disabled" if running else "normal"
        self.btn_buddy.configure(state=s)
        self.btn_stop.configure(state="normal" if running else "disabled")

    def _stop_all(self):
        self.running = False
        self.log("⏹ 중지 요청됨...")

    def log(self, msg: str):
        self.log_queue.put(msg)

    def _poll_log(self):
        while not self.log_queue.empty():
            msg = self.log_queue.get()
            self.log_text.configure(state="normal")
            self.log_text.insert("end", msg + "\n")
            self.log_text.see("end")
            self.log_text.configure(state="disabled")
        self.root.after(200, self._poll_log)

    # ── 실행 ─────────────────────────────────────────────────────

    def _validate(self) -> dict | None:
        if not SELENIUM_OK:
            messagebox.showerror("패키지 오류",
                "selenium, webdriver-manager 패키지가 필요합니다.\n\n"
                "CMD: pip install selenium webdriver-manager")
            return None
        if not self.var_keyword.get().strip():
            messagebox.showwarning("키워드 입력", "검색 키워드를 입력하세요.")
            return None
        import urllib.request
        try:
            urllib.request.urlopen("http://127.0.0.1:9222/json", timeout=2)
        except Exception:
            messagebox.showerror(
                "Chrome 연결 실패",
                "Chrome이 디버그 모드로 실행되지 않았습니다.\n\n"
                "프로그램 내 '① Chrome 시작' 버튼을 먼저 클릭하고\n"
                "네이버에 로그인한 뒤 다시 시도하세요."
            )
            return None
        return self._get_config()

    def _launch_chrome(self):
        import urllib.request
        import subprocess
        try:
            urllib.request.urlopen("http://127.0.0.1:9222/json", timeout=2)
            self.log("Chrome이 이미 실행 중입니다. 네이버에 로그인 후 ② 버튼을 누르세요.")
            return
        except Exception:
            pass

        if platform.system() == "Darwin":
            chrome_paths = [
                "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
                os.path.expanduser("~/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"),
            ]
        else:
            chrome_paths = [
                r"C:\Program Files\Google\Chrome\Application\chrome.exe",
                r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
                os.path.join(os.environ.get("LOCALAPPDATA", ""),
                             r"Google\Chrome\Application\chrome.exe"),
            ]
        chrome_exe = next((p for p in chrome_paths if os.path.exists(p)), None)
        if not chrome_exe:
            messagebox.showerror("오류", "Chrome을 찾을 수 없습니다.\nChrome이 설치되어 있는지 확인하세요.")
            return

        profile_dir = os.path.join(tempfile.gettempdir(), "nbolg_chrome")
        subprocess.Popen([
            chrome_exe,
            "--remote-debugging-port=9222",
            f"--user-data-dir={profile_dir}",
            "https://nid.naver.com/nidlogin.login",
        ])
        self.log("Chrome을 시작했습니다.")
        self.log("네이버에 로그인한 뒤 ② 서로이웃 시작 버튼을 누르세요.")

    def _start_buddy(self):
        cfg = self._validate()
        if not cfg:
            return
        self.running = True
        self._set_buttons(True)
        threading.Thread(target=self._buddy_worker, args=(cfg,), daemon=True).start()

    # ── 워커 ─────────────────────────────────────────────────────

    def _buddy_worker(self, cfg: dict):
        driver = None
        try:
            self.log("=" * 40)
            self.log("▶ 서로이웃 자동화 시작")
            self.log("Chrome 실행 중... (기존 로그인 세션 사용)")
            driver = self._create_driver()

            self.log(f"블로그 ID 수집 중... 키워드: '{cfg['keyword']}', 스크롤: {cfg['scroll_count']}회")
            blog_ids = self._collect_blog_ids(driver, cfg["keyword"], cfg["scroll_count"])
            if not blog_ids:
                self.log("수집된 블로그 ID가 없습니다.")
                return
            self.log(f"수집 완료: {len(blog_ids)}명")

            interval = cfg["buddy_interval"]
            success = 0
            for i, bid in enumerate(blog_ids):
                if not self.running:
                    break
                self.log(f"[{i+1}/{len(blog_ids)}] {bid}")
                if self._add_buddy(driver, bid, cfg["buddy_msg"]):
                    success += 1
                if i < len(blog_ids) - 1 and self.running:
                    delay = random.uniform(max(5, interval - 2), interval + 3)
                    self.log(f"  → {delay:.1f}초 대기...")
                    time.sleep(delay)

            self.log(f"▶ 완료: {success}/{len(blog_ids)}명 신청 성공")
        except Exception as e:
            self.log(f"[오류] {e}")
        finally:
            try:
                if driver:
                    driver.service.stop()
            except Exception:
                pass
            self.running = False
            self.root.after(0, lambda: self._set_buttons(False))

    # ── Selenium 헬퍼 ─────────────────────────────────────────────

    def _create_driver(self) -> webdriver.Chrome:
        options = webdriver.ChromeOptions()
        options.add_experimental_option("debuggerAddress", "127.0.0.1:9222")
        driver = webdriver.Chrome(
            service=Service(ChromeDriverManager().install()), options=options
        )
        return driver

    def _collect_blog_ids(self, driver: webdriver.Chrome,
                          keyword: str, scroll_count: int) -> list[str]:
        import re
        url = (
            f"https://m.search.naver.com/search.naver"
            f"?ssc=tab.m_blog.all&sm=mtb_jum"
            f"&query={quote(keyword)}&nso=so:dd,p:all"
        )
        driver.get(url)
        time.sleep(2)

        for i in range(scroll_count):
            driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            time.sleep(0.5)
            if (i + 1) % 5 == 0:
                self.log(f"  스크롤 {i+1}/{scroll_count}...")

        blog_ids: set[str] = set()
        pattern = re.compile(r'https?://m\.blog\.naver\.com/([^/?#]+)/\d+')
        for el in driver.find_elements(By.TAG_NAME, "a"):
            href = el.get_attribute("href") or ""
            m = pattern.match(href)
            if m:
                blog_ids.add(m.group(1))

        return list(blog_ids)

    # 서로이웃 '신청 불가'로 판단하는 안내 문구들 (꽉 참 / 닫음 / 거절·차단)
    #   네이버 실제 문구 기준. 모달·alert·페이지 어디서 떠도 텍스트로 잡아낸다.
    BLOCK_SIGNALS = (
        "이웃을 추가할 수 없",       # "더 이상 이웃을 추가할 수 없습니다" (5천명 초과)
        "이웃수가 5,000",            # "상대방의 이웃수가 5,000명이 초과되어"
        "5,000명이 초과",
        "더 이상 이웃",
        "이웃을 더 이상",
        "초과되어",
        "서로이웃을 신청할 수 없",   # 서로이웃 신청 닫음
        "서로이웃 신청을 받지 않",
        "이웃 신청을 받지 않",
        "신청이 마감",
        "신청할 수 없습니다",
        "차단",
    )

    def _blocked_reason(self, driver: webdriver.Chrome) -> str | None:
        """현재 화면(모달 포함)에 '신청 불가' 안내 문구가 있으면 그 문구를 반환."""
        try:
            body_text = driver.find_element(By.TAG_NAME, "body").text or ""
        except Exception:
            body_text = ""
        for sig in self.BLOCK_SIGNALS:
            if sig in body_text:
                return sig
        return None

    def _dismiss_popup(self, driver: webdriver.Chrome):
        """'확인' 등 팝업 닫기 버튼을 눌러 모달을 정리한다(다음 신청 방해 방지)."""
        try:
            for btn in driver.find_elements(By.CSS_SELECTOR,
                                            "button, a, .btn_ok, .btn_confirm"):
                try:
                    if (btn.text or "").strip() in ("확인", "닫기"):
                        driver.execute_script("arguments[0].click();", btn)
                        time.sleep(0.3)
                        return
                except Exception:
                    pass
        except Exception:
            pass

    def _add_buddy(self, driver: webdriver.Chrome, blog_id: str, message: str) -> bool:
        wait = WebDriverWait(driver, 10)
        try:
            driver.get(f"https://m.blog.naver.com/BuddyAddForm.naver?blogId={blog_id}")
            time.sleep(2)

            # ── 0) 페이지 진입 직후 '신청 불가' 상태 사전 감지 → 다음으로 ──
            reason = self._blocked_reason(driver)
            if reason:
                self.log(f"  [{blog_id}] 서로이웃 신청 불가({reason}) — 다음으로")
                self._dismiss_popup(driver)
                return False

            radios = driver.find_elements(By.CSS_SELECTOR, "input[type='radio']")
            if not radios:
                self.log(f"  [{blog_id}] 이미 이웃이거나 신청 불가 — 다음으로")
                return False

            # ── 1) 오직 '서로이웃' 라디오만 선택 (일반 이웃 폴백 제거) ──
            buddy_radio = None
            for radio in radios:
                try:
                    label_text = driver.execute_script(
                        "var r=arguments[0]; "
                        "var p=r.parentElement; "
                        "return p ? p.innerText : '';", radio)
                except Exception:
                    label_text = ""
                if "서로이웃" in (label_text or ""):
                    buddy_radio = radio
                    break

            # 서로이웃 항목 자체가 없음 = 상대가 서로이웃을 닫았거나 꽉 참 → 다음으로
            if buddy_radio is None:
                self.log(f"  [{blog_id}] 서로이웃 항목 없음(신청 닫힘/이웃 꽉 참) — 다음으로")
                return False

            # 서로이웃 라디오가 비활성(disabled)이면 신청 불가 → 다음으로
            if not buddy_radio.is_enabled() or buddy_radio.get_attribute("disabled"):
                self.log(f"  [{blog_id}] 서로이웃 신청 불가(비활성) — 다음으로")
                return False

            driver.execute_script("arguments[0].click();", buddy_radio)
            time.sleep(0.7)

            # ── 1-1) 서로이웃 선택 직후 뜨는 모달 감지 (예: 5,000명 초과) → 다음으로 ──
            reason = self._blocked_reason(driver)
            if reason:
                self.log(f"  [{blog_id}] 서로이웃 신청 불가({reason}) — 다음으로")
                self._dismiss_popup(driver)
                return False

            try:
                sel_el = wait.until(EC.presence_of_element_located(
                    (By.CSS_SELECTOR, "#buddyGroupSelect, select[name*='group'], select[name*='Group']")))
                sel = Select(sel_el)
                if sel.options:
                    sel.select_by_index(len(sel.options) - 1)
                time.sleep(0.3)
            except Exception:
                pass

            try:
                msg_box = wait.until(EC.visibility_of_element_located(
                    (By.CSS_SELECTOR,
                     "textarea#buddyAddMessage, textarea[name='addMessage'], textarea")))
                msg_box.clear()
                time.sleep(0.2)
                msg_box.send_keys(message[:400])
                time.sleep(0.3)
            except Exception:
                pass

            confirm = wait.until(EC.element_to_be_clickable(
                (By.CSS_SELECTOR,
                 "button.btn_confirm, input[type='submit'], button[type='submit'], "
                 "a.btn_ok, .btn_area button, button.confirm")))
            driver.execute_script("arguments[0].click();", confirm)
            time.sleep(1)

            # ── 신청 직후 경고창(거절/불가/꽉 참) 처리 → 닫고 다음으로 ──
            try:
                alert = driver.switch_to.alert
                alert_text = alert.text or ""
                alert.accept()
                self.log(f"  [{blog_id}] 신청 거절/불가({alert_text.strip()}) — 다음으로")
                return False
            except Exception:
                pass

            # ── 신청 후 페이지/모달 텍스트로 거절·불가 메시지 재확인 ──
            reason = self._blocked_reason(driver)
            if reason:
                self.log(f"  [{blog_id}] 신청 거절/불가({reason}) — 다음으로")
                self._dismiss_popup(driver)
                return False

            self.log(f"  [{blog_id}] ✓ 서로이웃 신청 완료")
            return True
        except Exception as e:
            self.log(f"  [{blog_id}] 오류 → 다음으로: {e}")
            return False


def main():
    root = tk.Tk()
    NaverAutoApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
