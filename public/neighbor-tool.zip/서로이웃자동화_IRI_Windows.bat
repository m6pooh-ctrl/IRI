@echo off
cd /d "%~dp0"
title Seoiyut Jadonghwa IRI - Setup and Run

echo.
echo  ====================================================
echo   Seoiyut Jadonghwa IRI  ^|  Windows
echo  ====================================================
echo.

python --version > nul 2>&1
if errorlevel 1 (
    echo  [ERROR] Python is not installed.
    echo.
    echo  Install Python 3.9+ from:
    echo    https://www.python.org/downloads/
    echo.
    echo  Be sure to check "Add Python to PATH".
    echo.
    pause
    exit /b 1
)

echo  [1/2] Checking selenium...
python -c "import selenium" > nul 2>&1
if errorlevel 1 (
    echo        Installing... (first time only)
    python -m pip install selenium -q
    if errorlevel 1 (
        echo  [ERROR] Failed to install selenium. Check your internet connection.
        pause
        exit /b 1
    )
)

echo  [2/2] Checking webdriver-manager...
python -c "import webdriver_manager" > nul 2>&1
if errorlevel 1 (
    echo        Installing... (first time only)
    python -m pip install webdriver-manager -q
    if errorlevel 1 (
        echo  [ERROR] Failed to install webdriver-manager. Check your internet connection.
        pause
        exit /b 1
    )
)

echo.
echo  Ready. Starting the program...
echo.

rem Resolve the real pythonw.exe so no black console window appears.
rem (The WindowsApps "pythonw" alias spawns a console window.)
set "PYW="
for /f "delims=" %%p in ('python -c "import sys, os; print(os.path.join(sys.exec_prefix, 'pythonw.exe'))"') do set "PYW=%%p"

if defined PYW if exist "%PYW%" (
    start "" "%PYW%" main.py
) else (
    start "" pythonw main.py
)
exit
