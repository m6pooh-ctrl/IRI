#!/bin/bash
# 서로이웃자동화_IRI_Mac.command
# Mac에서 더블클릭으로 실행하는 파일입니다.
#
# [처음 한 번만] 더블클릭이 막히면(권한/보안 경고) 터미널에서 아래처럼 실행하세요:
#   1) 터미널에 "bash " 입력 후 한 칸 띄우기
#   2) 이 파일을 터미널 창으로 드래그
#   3) Enter
#   → 한 번 실행하면 자동으로 실행권한·격리(Gatekeeper)가 풀려 다음부터는 더블클릭됩니다.

cd "$(dirname "$0")"

# 첫 실행 시 자가복구: 실행권한(+x) 부여 + 격리 속성 해제 → 다음부터 더블클릭 가능
chmod +x "$0" 2>/dev/null
xattr -dr com.apple.quarantine "$(dirname "$0")" 2>/dev/null

# Python3 설치 확인
if ! command -v python3 &>/dev/null; then
    echo "[ERROR] Python3 is not installed."
    echo "Please install Python 3.9+ from https://www.python.org"
    read -p "Press Enter to exit..."
    exit 1
fi

# selenium 설치 확인
python3 -c "import selenium" 2>/dev/null || {
    echo "Installing selenium..."
    python3 -m pip install selenium
}

# webdriver-manager 설치 확인
python3 -c "import webdriver_manager" 2>/dev/null || {
    echo "Installing webdriver-manager..."
    python3 -m pip install webdriver-manager
}

# GUI를 백그라운드로 실행하고 터미널 창은 닫는다 (검은 창 최소화)
python3 main.py &
exit 0
